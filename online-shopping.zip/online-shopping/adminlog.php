<?php

$username="Admin";
$password="admin";

$inputname=$_POST['username'];
$inputpwd=$_POST['password'];

if(($username==$inputname) && ($password==$inputpwd))
 header("Location: http://localhost/online-shopping/admin/index.php");
else 
 echo "<script>alert('Invalid Credinails');
 window.location.href='http://localhost/online-shopping/admin.php';</script>";
?>
